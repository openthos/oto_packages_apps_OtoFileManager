#!/bin/sh

#if [ $# -ne 2 ];then
#	echo "Usage: $0 user password"
#	exit
#fi

cd `dirname $0`
pwd
source enV

bin/net $@

